import { DashboardHeaderRoles } from './dashboard-header-roles';

describe('DashboardHeaderRoles', () => {
  it('should create an instance', () => {
    expect(new DashboardHeaderRoles()).toBeTruthy();
  });
});
