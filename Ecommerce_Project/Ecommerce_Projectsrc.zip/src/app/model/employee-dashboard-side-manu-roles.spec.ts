import { EmployeeDashboardSideManuRoles } from './employee-dashboard-side-manu-roles';

describe('EmployeeDashboardSideManuRoles', () => {
  it('should create an instance', () => {
    expect(new EmployeeDashboardSideManuRoles()).toBeTruthy();
  });
});
