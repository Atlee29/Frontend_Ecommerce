export class UserDetails {
    userId:number;
    userName:string;
    password:string;
    userType:string;
}
