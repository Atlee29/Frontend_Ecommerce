import { Products } from "./products";

export class OrderDetails {
    orderId:number;
    productQuantity:number;
    products:Products[];

}
