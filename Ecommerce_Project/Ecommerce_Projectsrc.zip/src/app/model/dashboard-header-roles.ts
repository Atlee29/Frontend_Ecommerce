export class DashboardHeaderRoles {

    public static dashHeaderRoles : Array<any>=[
        
        {lable:'Abouts',path:'aboutus'},
        {lable:'Reviews',path:'review'},
        {lable:'Login',path:'login'},
        {lable:'Contact',path:'contact'},
        
    ]
}
