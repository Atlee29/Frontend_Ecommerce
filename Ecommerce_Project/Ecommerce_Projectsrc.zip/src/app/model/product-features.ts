export class ProductFeatures {
    productFeatureId:number;
    productFeatureName:string;
    productFeatureValue:string;
}
