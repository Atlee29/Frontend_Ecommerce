import { BankDetail } from './bank-details';

describe('BankDetail', () => {
  it('should create an instance', () => {
    expect(new BankDetail()).toBeTruthy();
  });
});
